function myBirthYearFunc(){
        console.log("Nací en " + 1980);
    }
    // el console.log imprime nací en 1980
    function myBirthYearFunc(EntradaAñoNacimiento){
        console.log("Nací en " + EntradaAñoNacimiento);
    }
    // el console.log imprime nací en 1980
    function add(num1, num2){
        console.log("¡Sumando números!");
        console.log("num1 is: " + num1);
        console.log("num2 is: " + num2);
        var sum = num1 + num2;
        console.log(sum);
    }
    /* el console.log imprime "sumando números"
    el console.log imprime num1
    el console.log imprime num1
    el console.log imprime resultado "30"*/